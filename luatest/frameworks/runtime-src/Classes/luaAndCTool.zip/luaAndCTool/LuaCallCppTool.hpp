//
//  LuaCallCppTool.hpp
//  luatest
//
//  Created by woodcol on 15/11/6.
//
//

#ifndef LuaCallCppTool_hpp
#define LuaCallCppTool_hpp

#include <stdio.h>

extern "C" {
    const char* getLuaCallCppPath();
}

const char* getLuaCallCppPath();

#endif /* LuaCallCppTool_hpp */
